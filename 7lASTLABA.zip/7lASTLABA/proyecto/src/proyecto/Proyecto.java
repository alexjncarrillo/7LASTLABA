/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class Proyecto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     int A;
     
     System.out.print("ingrese cantidad");
     Scanner D1 = new Scanner (System.in);
     A = D1.nextInt();
     
     if (A%2==0) {
      System.out.println(A+"es par");
      
      
    }else{
    
         System.out.println(A+"es impar");{
        
    }
    }
