/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.pkg2;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class Proyecto2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String nombre = "alex";
        String apellido = "carrillo";
        
        System.out.print("ingrese su nombre");
        Scanner n = new Scanner(System.in);
        nombre = n.nextLine();
        
        System.out.print("ingrese su apellido");
        Scanner p = new Scanner(System.in);
        apellido = p.nextLine();
        
        System.out.print("bienvenidos al usuario "+nombre +apellido);
    }
    
}
